package com.demo.bean;



public class User {
	
	private String uemail;
	private String uname;       //User handle
	private String ufullName;   //User full name
	private String ucity;
	private String ucompany;
	private int uid;
	
	//Default Constructor
	public User() {
		super();
	}

	//Parameterized constructor
	public User(String uemail, String uname, String ufullName, String ucity, String ucompany, int uid) {
		super();
		this.uemail = uemail;
		this.uname = uname;
		this.ufullName = ufullName;
		this.ucity = ucity;
		this.ucompany = ucompany;
		this.uid = uid;
	}
	
	//Parameterized Constructor for add to block user list in data-access layer
	public User(int uid, String uemail) {
		super();
		this.uemail = uemail;
		this.uid = uid;
	}

	//toString method to display data member values 
	@Override
	public String toString() {
		return "User [uemail=" + uemail + ", uname=" + uname + ", ufullName=" + ufullName + ", ucity=" + ucity
				+ ", ucompany=" + ucompany + ", uid=" + uid + "]";
	}

	//getter and setter methods to retrieve and set value of data members
	public String getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail = uemail;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUfullName() {
		return ufullName;
	}

	public void setUfullName(String ufullName) {
		this.ufullName = ufullName;
	}

	public String getUcity() {
		return ucity;
	}

	public void setUcity(String ucity) {
		this.ucity = ucity;
	}

	public String getUcompany() {
		return ucompany;
	}

	public void setUcompany(String ucompany) {
		this.ucompany = ucompany;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}


	

	
}