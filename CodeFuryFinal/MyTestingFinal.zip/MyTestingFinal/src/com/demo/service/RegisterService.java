package com.demo.service;

import com.demo.bean.User;

public interface RegisterService {

	public boolean saveDetails(User userDetails);
	

}
