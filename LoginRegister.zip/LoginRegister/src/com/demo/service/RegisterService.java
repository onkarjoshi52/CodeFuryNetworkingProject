package com.demo.service;

import com.demo.bean.UserDetails;

public interface RegisterService {

	public boolean saveDetails(UserDetails userDetails);
	

}
